﻿namespace StudentMVC.ExceptionHandler
{
    public class StudentException : Exception
    {
        public StudentException(String Message) :base(Message){ }
    }
}
